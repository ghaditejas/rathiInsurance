//make sagas to send GET/POST request
import { Constants } from "../../helpers/constant";

function* apiCall(params) {
  //console.log("api call params==>", params);
  let path = `${Constants.baseURL}${params.url}`;
  let token = JSON.parse(localStorage.getItem("Token"));
  var myHeaders = new Headers();
  myHeaders.append("Content-Type", "application/json");

  if (params.url !== "/login") {
    myHeaders.append("Authorization", `Bearer ${token}`);
  }

  var requestOptions = {
    method: params.method,
    headers: myHeaders,
    redirect: "follow",
  };

  if (params.params.params) {
    var raw = JSON.stringify(params.params.params);
    requestOptions.body = raw;
  }

  const response = yield fetch(path, requestOptions).then(function (response) {
    let res = { status: "ERROR", message: "" };
    //handle invalid token
    if (response.status === 401) {
      res.message = "Your session has expired. Please login to continue";
      localStorage.removeItem("Token");
      params.params.history.replace("/login");
      return res;
    } else if (response.status === 404) {
      res.message = "Page not found";
      return res;
    } else if (response.status === 500) {
      res.message = "Service temporarily unavailable";
      return res;
    } else {
      return response.json();
    }
  });
  return response;
}

export const Api = {
  apiCall,
};
