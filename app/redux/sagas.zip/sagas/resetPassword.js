import { put, takeLatest, all } from "redux-saga/effects";
import axios from "axios";
import { API_HOST } from "../../lib/constants/assets";

function* ResetPassword(params) {
  try {
    let res = yield axios.post(`${API_HOST}/reset-password`, params.resetPasswordDetails, {
      headers: {
        "Content-Type": "text/plain",
      },
    });
    console.log(res.data,'res.data');
    if (res.data.status == "02") {
      yield put({
        type: "ResetPasswordError",
        payload: { message: res.data.message },
      });
    } else {
      yield put({ type: "ResetPassword", payload: res.data.message });
    }
  } catch {
    yield put({
      type: "ResetPasswordError",
      payload: { message: "Service Unavailable Try again later" },
    });
  }
}

export function* watchReset() {
  yield takeLatest("RESET_PASSWORD", ResetPassword);
}

