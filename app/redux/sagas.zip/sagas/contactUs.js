import { put, takeLatest, all } from "redux-saga/effects";
import axios from "axios";
import { API_HOST } from "../../lib/constants/assets";

function* ContactUS(params) {
  try {
    let res = yield axios.post(`${API_HOST}/email`, params.contactUsDetails, {
      headers: {
        "Content-Type": "text/plain",
      },
    });
    if (res.data.status == "ERROR") {
      yield put({
        type: "ContactUsError",
        payload: { message: res.data.message },
      });
    } else {
      yield put({ type: "ContactUS", payload: res.data.message });
    }
  } catch {
    yield put({
      type: "ContactUsError",
      payload: { message: "Service Unavailable Try again later" },
    });
  }
}

function* ResetContact() {
  yield put({ type: "ResetContactUS" });
}

export function* watchContact() {
  yield takeLatest("CONTACT_US", ContactUS);
  yield takeLatest("RESET_CONTACT_US", ResetContact);
}

