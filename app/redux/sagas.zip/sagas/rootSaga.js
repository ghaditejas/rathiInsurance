import { call, all, fork } from "redux-saga/effects";
// 'call' effect run a saga with params
import {watchReset} from "./resetPassword";
import {watchContact } from "./contactUs";

export default function* rootSaga() {
  console.log("in root saga");
  yield all([
    fork(watchReset),
    fork(watchContact),
  ]);
  // yield call(watchFetchList);
  // yield call(watchFetchItem);
}
